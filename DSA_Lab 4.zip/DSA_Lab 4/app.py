# app.py

from flask import Flask, render_template, request
import math
from stack import Stack, infix_to_postfix

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/profile')
def profile():
    return render_template('profile.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/skills')
def skills():
    return render_template('skills.html')

@app.route('/works')
def works():
    return render_template('works.html')

@app.route('/contact', methods=['GET', 'POST'])
def contact():
    message_sent = False
    if request.method == 'POST':
        message_sent = True
    return render_template('contact.html', message_sent=message_sent)

@app.route('/touppercase', methods=['GET', 'POST'])
def touppercase():
    result = None
    if request.method == 'POST':
        input_string = request.form.get('inputString', '')
        result = input_string.upper()
    return render_template('touppercase.html', result=result)

@app.route('/circle', methods=['GET', 'POST'])
def circle():
    area = None
    if request.method == 'POST':
        try:
            radius = float(request.form.get('radius', 0))
            area = round(math.pi * (radius ** 2), 2)
        except ValueError:
            area = "Invalid input"
    return render_template('circle.html', area=area)

@app.route('/triangle', methods=['GET', 'POST'])
def triangle():
    area = None
    if request.method == 'POST':
        try:
            base = float(request.form.get('base', 0))
            height = float(request.form.get('height', 0))
            area = round(0.5 * base * height, 2)
        except ValueError:
            area = "Invalid input"
    return render_template('triangle.html', area=area)

@app.route('/infix-to-postfix', methods=['GET', 'POST'])
def postfix_converter():
    result = None
    expression = ""
    if request.method == 'POST':
        expression = request.form.get('expression', '')
        if expression:
            result = infix_to_postfix(expression)
    return render_template('postfix.html', result=result, expression=expression)

if __name__ == '__main__':
    app.run(debug=True)