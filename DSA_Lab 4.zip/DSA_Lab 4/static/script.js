document.addEventListener('DOMContentLoaded', () => {
    const revealItems = document.querySelectorAll('.reveal');
    revealItems.forEach((item, index) => {
        item.style.animationDelay = `${index * 100}ms`;
    });

    const card = document.querySelector('.profile-frame');
    if (card) {
        document.addEventListener('pointermove', (event) => {
            const { innerWidth, innerHeight } = window;
            const rotateY = ((event.clientX / innerWidth) - 0.5) * 12;
            const rotateX = (0.5 - (event.clientY / innerHeight)) * 12;
            card.style.transform = `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });

        document.addEventListener('pointerleave', () => {
            card.style.transform = 'rotateX(0deg) rotateY(0deg)';
        });
    }
});
